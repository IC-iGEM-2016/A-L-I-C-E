<?php
/**
* The base configuration for WordPress
*
* The wp-config.php creation script uses this file during the
* installation. You don't have to use the web site, you can
* copy this file to "wp-config.php" and fill in the values.
*
* This file contains the following configurations:
*
* * MySQL settings
* * Secret keys
* * Database table prefix
* * ABSPATH
*
* @link https://codex.wordpress.org/Editing_wp-config.php
*
* @package WordPress
*/
// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('WP_CACHE', true); //Added by WP-Cache Manager
define( 'WPCACHEHOME', '/srv/disk5/2185738/www/ecolibrium.eu.pn/wp-content/plugins/wp-super-cache/' ); //Added by WP-Cache Manager
define('DB_NAME', '2185738_86aa');
/** MySQL database username */
define('DB_USER', '2185738_86aa');
/** MySQL database password */
define('DB_PASSWORD', 'igem2016');
/** MySQL hostname */
define('DB_HOST', 'fdb15.runhosting.com');
/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');
/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');
/**#@+
* Authentication Unique Keys and Salts.
*
* Change these to different unique phrases!
* You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
* You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
*
* @since 2.6.0
*/
define('AUTH_KEY',         '%AEehW~^mC{K^w-0NbQT-(mogX0m_)Fv#gbXp^a[u!e5.NBkS#kbiO]~v[630}HB');
define('SECURE_AUTH_KEY',  'kW,)aeTQ-N$5$FF,rOrtZ.[Lq3e!eNJZ duLjR-#%HgU#(L^1BI(Z4J67)5|6.ru');
define('LOGGED_IN_KEY',    'HNh*1G/t: >raAG+S9ltaJTQ2W:oF=21>b<1J_Tj8s0]U8#mdw*+&yX(VA.zuu|Z');
define('NONCE_KEY',        'YNs In*C8iBt,saumJk|_$x#5QER}M|i Ggyd<q+PiU%mY2S_1E`2F(N:%&gtei{');
define('AUTH_SALT',        'yx<u;8{ aRb5N(_.i4ty56E=0x9l/k)Zum9JH;-rk5Y4uP+?NG:+vf>sY-vHM;5=');
define('SECURE_AUTH_SALT', 'l7hEBu~!CU2e#rU&ES~~jJ}e}UW}AvvMsD ~1F2zp*~sMk<~{hqP+;ev4N0?4R%A');
define('LOGGED_IN_SALT',   ';9F<g~?8)LcJU=|nE/|.~#]_ac5FU3xm4txm4gCYmn%2I}0aP1POGhExFC>VeG{W');
define('NONCE_SALT',       '~ge=X~H{a[-AThuX5Xa,p5zyPiKNQ7kUk/;[,LC, qwg>^`-jd-w;>x]u8Z.&`Ox');
/**#@-*/
/**
* WordPress Database Table prefix.
*
* You can have multiple installations in one database if you give each
* a unique prefix. Only numbers, letters, and underscores please!
*/
$table_prefix  = 'wp_igem';
/**
* For developers: WordPress debugging mode.
*
* Change this to true to enable the display of notices during development.
* It is strongly recommended that plugin and theme developers use WP_DEBUG
* in their development environments.
*
* For information on other constants that can be used for debugging,
* visit the Codex.
*
* @link https://codex.wordpress.org/Debugging_in_WordPress
*/
define('WP_DEBUG', false);
/* That's all, stop editing! Happy blogging. */
/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
define('ABSPATH', dirname(__FILE__) . '/');
/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
