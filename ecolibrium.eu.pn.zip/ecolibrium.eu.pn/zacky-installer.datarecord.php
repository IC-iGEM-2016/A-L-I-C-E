<?php /*

This file contains internal information for the Zacky Installer.
Do NOT change. Removing it might prevent you from using the installer 
on this installation in the future.

---
QlpoOTFBWSZTWauFHIYAAL9fgEAQQId/8CjgjBC/7/+7MAF5rMzDVHppNJtT1GT1PUMTTTEDTIAw
NQNBGQ0I0NAAGgGhoNT0gJqnim21IxRtEADTT1DTTIPp9DDmDpAMkBBgGhYIny5ctznhkiCUILNl
+eEAMsIInzdiW5GfbKXFeOP3pggM7bAWV7g3e7rc4qjk3is6wGLLVUFAlsM06BI6VEoFQ4dLia7S
fIbCJZ2ypZTG2D3kTNH6qhCkAaVpeXEDhXZSprw7VZIFmsh7Q2sSIrl0CUUTbzgBJ2GASnRahy4E
9baSmlmQ9ftuwOPwFdjIBjhesHDrxdPP56NosU+dLKySQXCJkA10pYn9FGGg8MQvxgWqTsK514kn
VlXgMJjCyg8fxKrpFE7jzpM96IObecQakNcmYhQ+qxQEEPNHUhMZtcimVs3qQim1LGAWEpvtHPLB
XB+QWes2+lGJFEEcGSt0fCZCHG0iIULkIMuES1a1ek6i0xFTUadt3P/z2x6s7rherVIzGxWs4VXZ
C7kinChIVcKOQwA=

...

*/
